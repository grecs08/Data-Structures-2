JobID: cp264-a7
Name: Andrew Greco
ID: 210422740

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description


Q1 Basic binary tree and operations
Q1.1 [3/3/*] get_props()                             
Q1.2 [3/3/*] display_preorder/inorder/postorder()    
Q1.3 [3/3/*] display_bforder()                       
Q1.4 [3/3/*] iterative_bfs()                         
Q1.5 [3/3/*] iterative_dfs()                         

Q2 BST for record data
Q2.1 [2/3/*] search()                                
Q2.2 [2/3/*] insert()                                
Q2.3 [2/3/*] delete()                                

Q3 BST for record data processing
Q3.1 [3/3/*] add_data()                              
Q3.2 [3/3/*] remove_data()                           

Total: [27/30/*]


